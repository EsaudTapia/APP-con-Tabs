import 'package:flutter/material.dart';
import 'package:tab_app/src/tabs.dart';
void main() {
  runApp(
      MaterialApp(
        home:Mytabs() ,
      )

  );
}

